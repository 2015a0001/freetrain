## Additional plug-in set for FreeTrainEx [September 2005] ##
This package is a collection of plug-ins which are published in several web sites 
at the date of September 03, 2005, with the permit of each authors.

#Disclaimer
I did not verify whether all plug-ins work correctly.

Followings are sites and authors who agreed with packaging there works.
(Most of sites are Japanese only)

+Hima san: FreeTrain total train yard
 http://suzukams.at.infoseek.co.jp/FreeTrain/
+Ayase san: FreeTrain support site
 http://www14.big.or.jp/~ayase/freetrain/
+T.Hara san: Starting FreeTrain
 http://park8.wakwak.com/~bast/freetrain/
+C477: FreeTrain urban development office
 http://www.rocket.ne.jp/~nao/
+Daifukyo san: FreeTrain Daifukyo kokusai zaibatsu
 http://www63.tok2.com/home2/sinndokusaisya/daihukyou/FreeTrain/index.html
+Kei san: FreeTrain Small yard
 http://www.h2.dion.ne.jp/~kei_s/freetrain/
+qra_ra san: FreeTrain Sousaku kan
 http://hb4.seikyou.ne.jp/home/Go-Ro/FreeTrain/
+HEUER san: FreeTrain construction consultant
 http://freetrain.finito-web.com/
+Itchy san: FreeTrain plugins yard
 http://www.geocities.jp/cyber_express_1703d/freetrain/
+Typhoon san: Plugins yard for FreeTrain
 http://typhoon.s19.xrea.com/ft/index.html
+Altima san: ZeroDimensions
 http://zero-d.web.infoseek.co.jp/
+HINOTO san: Boss Takyakurin in tears.
 http://www4.ocn.ne.jp/~presto/ft/
+Shikashika san: FreeTrain shisen tour support corp.
 http://shikashika.hp.infoseek.co.jp/
+Namoh san: Aich pref. private plugin factory
 http://www.medias.co.jp/~bell8528/freetrain/index.html
+Tomonori Takeuchi san: Tomonori Takeuchi's homepage
 http://f4.aaa.livedoor.jp/~tomo/free_train/ft.html

+Authors of which plugins published on "total train yard", the site of Hima san.
 Hima san, Kawaguchi Kohsuke san, Min san, qra_ra(haru) san, Kigami san
 TAKUROU san, iwasaki san, T.Hara san, Ayase san, ima san, 1500v san, 
 Nanashi-san@Hokkaido san, Ken san, Mumei no hito san, Hatena kun san, 
 Nanashi-san no yabo san, masashi san

+Authors of which plugins posted on uploder at "www.kosuke.org/freetrain".
 Kei san, TAKUROU san, Ken san, Yua san, Sakuranishi mokeibu san, 
 RougetsuRouya san, Nanashi(kanji) san, haru san, Shino san, Nanashi-san san, 
 Te san, Moo05 san, Nanashi(kana) san, Ekio san, Hanabishi san, ChousenShitaHito san
*The post no.450 and no.633 are modified not to replace Hanabishi san's plugin.
*The name of  Hanabishi san's plugin folders are renamed as follows.
 jp.big.ayase.freetrain.* -> org.kosuke.freetrain.*

#Thanks
I appreciate in everyone authors above-mentioned.

*If you are an author of any plugin included in this package,
 And you do not want your plugins included in any more,
 please contact me (E-mail:rc-nao@rocket.ne.jp).

-----------------------------------------------------
C477(chiname)
E-mail:rc-nao@rocket.ne.jp