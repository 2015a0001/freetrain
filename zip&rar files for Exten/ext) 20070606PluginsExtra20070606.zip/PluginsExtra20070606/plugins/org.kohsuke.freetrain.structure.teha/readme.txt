﻿ダウンロードありがとう御座います。

とりあえずこのファイルは作成中のプラグインをとりあえず一纏めしたモノです。
(辱めとも言いますね…)
たいしたモノが無かったり、使い道が難しかったりするモノばかりですが、何かのお役に立てれば光栄デス。

…とはいえ、作成中のモノの方が多すぎて使えるモノは殆ど無いかと思いますが…(つд｀)
ちなみに11日バージョンのみ対応しています…
後、私が作成したプラグインはご自由に改造したり別目的に利用したりして下さいな(ヘボすぎて使えないかと思いますが…)

Thank you for downloading this package.

This package is a collection of my plugins now under construction.
I'm glad if you enjoy with them.
Feel free to modify my plugins or apply for other purposes.

ては(T.Hara)